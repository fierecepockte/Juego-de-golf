package Juego;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class PantallaInicio {

    private static final int WIDTH = 1280;
    private static final int HEIGHT = 720;

    public Scene crearPantalla(Stage stage) {
        // Fondo
        Image bgImage = new Image(getClass().getResource("/assets/fondo ofc.png").toExternalForm());
        BackgroundImage bg = new BackgroundImage(bgImage,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(100, 100, true, true, false, true));

        StackPane fondo = new StackPane();
        fondo.setPrefSize(WIDTH, HEIGHT);
        fondo.setBackground(new Background(bg));

        // Botones con imágenes transparentes
        Button jugarBtn = new Button();
        Button salirBtn = new Button();

        String transparentStyle = "-fx-background-color: transparent; -fx-border-color: transparent;";
        jugarBtn.setStyle(transparentStyle);
        salirBtn.setStyle(transparentStyle);

        Image jugarImg = new Image(getClass().getResource("/assets/playofc.png").toExternalForm());
        Image salirImg = new Image(getClass().getResource("/assets/exitofc.png").toExternalForm());

        double btnWidth = 160;

        ImageView jugarView = new ImageView(jugarImg);
        jugarView.setFitWidth(btnWidth);
        jugarView.setPreserveRatio(true);

        ImageView salirView = new ImageView(salirImg);
        salirView.setFitWidth(btnWidth);
        salirView.setPreserveRatio(true);

        jugarBtn.setGraphic(jugarView);
        salirBtn.setGraphic(salirView);

        // Asegurar tamaño mínimo visible (opcional pero útil para pruebas)
        jugarBtn.setMinSize(160, 80);
        salirBtn.setMinSize(160, 80);

        // Acción de los botones
        jugarBtn.setOnAction(e -> {
            System.out.println("Botón Jugar presionado"); // Prueba en consola
            SeleccionCampo seleccion = new SeleccionCampo();
            Scene nuevaEscena = seleccion.crearPantalla(stage);
            stage.setScene(nuevaEscena);
        });

        salirBtn.setOnAction(e -> stage.close());

        // Botones lado a lado abajo a la izquierda
        HBox botones = new HBox(20, salirBtn, jugarBtn);
        botones.setAlignment(Pos.BOTTOM_LEFT);
        HBox.setMargin(salirBtn, new Insets(0, 0, 20, 20));
        HBox.setMargin(jugarBtn, new Insets(0, 0, 20, 0));

        StackPane.setAlignment(botones, Pos.BOTTOM_LEFT);
        fondo.getChildren().add(botones);

        return new Scene(fondo, WIDTH, HEIGHT);
    }
}
