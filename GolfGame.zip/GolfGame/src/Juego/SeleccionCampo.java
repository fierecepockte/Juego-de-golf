package Juego;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SeleccionCampo {

    private static final int WIDTH = 1920;
    private static final int HEIGHT = 1080;

    public Scene crearPantalla(Stage stage) {
        BorderPane root = new BorderPane();
        root.setPrefSize(WIDTH, HEIGHT);

        // Fondo
        Image bgImage = new Image(getClass().getResource("/assets/fond.png").toExternalForm());
        BackgroundImage bg = new BackgroundImage(bgImage,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(100, 100, true, true, false, true));
        root.setBackground(new Background(bg));

        // Cargar imágenes de los campos
        Image campo1 = new Image(getClass().getResource("/assets/campo1.png").toExternalForm());
        Image campo2 = new Image(getClass().getResource("/assets/campo2.png").toExternalForm());
        Image campo3 = new Image(getClass().getResource("/assets/campo3.png").toExternalForm());

        ImageView campo1View = crearVistaCampo(campo1, stage, "Campo 1");
        ImageView campo2View = crearVistaCampo(campo2, stage, "Campo 2");
        ImageView campo3View = crearVistaCampo(campo3, stage, "Campo 3");

        HBox camposBox = new HBox(60, campo1View, campo2View, campo3View);
        camposBox.setAlignment(Pos.CENTER);

        VBox centerLayout = new VBox(80, camposBox);
        centerLayout.setAlignment(Pos.CENTER);

        root.setCenter(centerLayout);
        return new Scene(root, WIDTH, HEIGHT);
    }

    private ImageView crearVistaCampo(Image imagen, Stage stage, String nombreCampo) {
        ImageView view = new ImageView(imagen);
        view.setFitWidth(400);
        view.setPreserveRatio(true);

        view.setOnMouseClicked(e -> {
            System.out.println("Seleccionaste: " + nombreCampo);
            // Aquí puedes iniciar la siguiente pantalla del juego
        });

        return view;
    }
}