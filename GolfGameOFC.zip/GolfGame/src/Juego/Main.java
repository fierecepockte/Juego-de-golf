package Juego;

import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        PantallaInicio pantalla = new PantallaInicio();
        primaryStage.setTitle("Teleswing");

        // Abrir en pantalla completa (maximizada)
        primaryStage.setMaximized(true);
        // También puedes usar fullScreen si lo prefieres:
        // primaryStage.setFullScreen(true);

        primaryStage.setScene(pantalla.crearPantalla(primaryStage));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
