package SonidoApp;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.*;
import javafx.scene.shape.ArcType;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

public class JuegoGolf extends Application {
    private static final double WIDTH      = 800;
    private static final double HEIGHT     = 600;
    private static final double FRICTION   = 0.99;
    private static final double ARC_RADIUS = 60;
    private static final double FOCAL      = 300;

    private Point2D ballPos2D    = new Point2D(0, 0);
    private double   ballZ       = 0;
    private Point2D velocity2D   = Point2D.ZERO;
    private double   velocityZ   = 0;
    private boolean  ballLaunched= false;

    private double power         = 0;
    private boolean charging     = false;
    private double aimAngle      = Math.PI / 2;

    private Canvas canvas;

    @Override
    public void start(Stage stage) {
        Pane root = new Pane();
        canvas = new Canvas(WIDTH, HEIGHT);
        root.getChildren().add(canvas);

        Scene scene = new Scene(root);
        setupInput(scene);

        new AnimationTimer() {
            private long last = 0;
            @Override
            public void handle(long now) {
                if (last == 0) last = now;
                double dt = (now - last) / 1e9;
                last = now;
                update(dt);
                render();
            }
        }.start();

        stage.setScene(scene);
        stage.setTitle("Mini Golf 3D con Fondo");
        stage.show();
    }

    private void setupInput(Scene scene) {
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.SPACE) {
                charging = true;
                power = 0;
            } else if (e.getCode() == KeyCode.LEFT) {
                aimAngle += Math.toRadians(2);
            } else if (e.getCode() == KeyCode.RIGHT) {
                aimAngle -= Math.toRadians(2);
            }
        });
        scene.setOnKeyReleased(e -> {
            if (e.getCode() == KeyCode.SPACE && charging) {
                charging = false;
                launchBall();
            }
        });
    }

    private void launchBall() {
        double maxSpeed2D = 600;
        double maxSpeedZ  = 800;
        velocity2D = new Point2D(
            Math.cos(aimAngle),
            Math.sin(aimAngle)
        ).multiply(maxSpeed2D * power);
        velocityZ = maxSpeedZ * power;
        ballLaunched = true;
    }

    private void update(double dt) {
        if (charging) {
            power = Math.min(1, power + dt * 1.2);
        }
        if (ballLaunched) {
            velocity2D = velocity2D.multiply(FRICTION);
            velocityZ  = velocityZ  * FRICTION;
            ballPos2D  = ballPos2D.add(velocity2D.multiply(dt));
            ballZ     += velocityZ * dt;
            if (ballZ < 0) ballZ = 0;
            if (velocity2D.magnitude() < 5 && velocityZ < 5) {
                ballLaunched = false;
            }
        }
    }

    private void render() {
        GraphicsContext gc = canvas.getGraphicsContext2D();

        // Fondo: cielo degradado
        gc.setFill(new LinearGradient(
            0, 0, 0, 1, true, CycleMethod.NO_CYCLE,
            new Stop(0, Color.LIGHTSKYBLUE),
            new Stop(1, Color.SKYBLUE)
        ));
        gc.fillRect(0, 0, WIDTH, HEIGHT);

        // Suelo verde
        gc.setFill(Color.FORESTGREEN);
        gc.fillRect(0, HEIGHT * 0.3, WIDTH, HEIGHT * 0.7);

        // Líneas de pista (perspectiva)
        gc.setStroke(Color.GRAY);
        for (int i = 0; i < 20; i++) {
            double t = i / 19.0;
            double y = HEIGHT * (0.3 + 0.7 * t);
            gc.strokeLine(0, y, WIDTH, y);
        }
        for (int i = 0; i < 15; i++) {
            double x = WIDTH/2 + (i - 7) * (WIDTH/30);
            gc.strokeLine(WIDTH/2, HEIGHT*0.3, x, HEIGHT);
        }

        // Perspectiva 3D
        double groundScale = FOCAL / (FOCAL + ballPos2D.getY());
        double bx = WIDTH/2 + ballPos2D.getX() * groundScale;
        double by = HEIGHT*0.75 - ballPos2D.getY() * groundScale - ballZ * groundScale;
        double radius = 15 * groundScale;

        // Sombra
        gc.setFill(Color.rgb(0, 0, 0, 0.3 * groundScale));
        double shadowR = radius * 1.2;
        gc.fillOval(bx - shadowR, HEIGHT*0.75 + 5, shadowR*2, shadowR/2);

        // Bola
        gc.setGlobalAlpha(groundScale);
        RadialGradient grad = new RadialGradient(
            0, 0, 0.3, 0.3, 1, true,
            CycleMethod.NO_CYCLE,
            new Stop(0, Color.WHITE), new Stop(1, Color.DARKGREEN)
        );
        gc.setFill(grad);
        gc.fillOval(bx - radius, by - radius, radius*2, radius*2);
        gc.setGlobalAlpha(1);

        // Medidor de potencia
        gc.setStroke(Color.DARKSLATEGRAY);
        gc.setLineWidth(ARC_RADIUS / 6);
        gc.strokeArc(
            WIDTH/2 - ARC_RADIUS,
            HEIGHT - (ARC_RADIUS + 20),
            ARC_RADIUS*2, ARC_RADIUS*2,
            0, 180, ArcType.OPEN
        );
        gc.setStroke(Color.LIMEGREEN);
        gc.strokeArc(
            WIDTH/2 - ARC_RADIUS,
            HEIGHT - (ARC_RADIUS + 20),
            ARC_RADIUS*2, ARC_RADIUS*2,
            0, power * 180, ArcType.OPEN
        );
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
