package SonidoApp;

import javafx.scene.media.AudioClip;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class SonidoManager {

    // Mapa que asocia clave → AudioClip
    private Map<String, AudioClip> clips = new HashMap<>();

    public SonidoManager() {
        // Lista de todos los archivos de sonido que tienes en src/sonidos
        String[] nombres = {
            "1 Open Surge score jingle - E",
            "2 Open Surge score jingle - D",
            "3 Open Surge score jingle - C",
            "4 Open Surge score jingle - B",
            "5 Open Surge score jingle - A",
            "6 Open Surge score jingle - AA",
            "7 Open Surge score jingle - AAA",
            "ambiente",
            "Hoyo",
            "Patearbalon",
            "SonidoInterfaz",
            "Voice1", "Voice2", "Voice3", "Voice4",
            "Voice5", "Voice6", "Voice7", "Voice8", "Voice9",
            "VoiceAlbatross", "VoiceBirdie", "VoiceBogey",
            "VoiceDoubleBogey", "VoiceEagle", "VoiceGiveUpHole",
            "VoiceHoleInOne", "VoiceHoleNumber", "VoiceOutOfBounds",
            "VoicePar", "VoiceShot", "VoiceTripleBogey"
        };

        for (String nombre : nombres) {
            // Determina extensión según el caso
            String ext = nombre.startsWith("1 ") || nombre.startsWith("2 ")
                       || nombre.startsWith("3 ") || nombre.startsWith("4 ")
                       || nombre.startsWith("5 ") || nombre.startsWith("6 ")
                       || nombre.startsWith("7 ")
                       ? ".ogg" 
                       : (nombre.startsWith("Voice") ? ".wav" : ".mp3");

            String recursoPath = "/sonidos/" + nombre + ext;
            try {
                URL recurso = getClass().getResource(recursoPath);
                if (recurso != null) {
                    AudioClip clip = new AudioClip(recurso.toString());
                    clip.setCycleCount(AudioClip.INDEFINITE);  // si quieres que algunos repitan
                    clips.put(nombre, clip);
                    System.out.println("✔ Cargado: " + nombre + ext);
                } else {
                    System.err.println("❌ No se encontró: " + recursoPath);
                }
            } catch (Exception e) {
                System.err.println("⚠ Error cargando " + nombre + ext + ": " + e.getMessage());
            }
        }
    }

    /** Reproduce el sonido identificado por su clave (nombre sin extensión). */
    public void reproducir(String clave) {
        AudioClip clip = clips.get(clave);
        if (clip != null) {
            clip.play();
            System.out.println("🎵 Reproduciendo: " + clave);
        } else {
            System.err.println("❌ Sonido '"+ clave +"' no cargado.");
        }
    }

    /** Detiene el sonido identificado por su clave. */
    public void detener(String clave) {
        AudioClip clip = clips.get(clave);
        if (clip != null) {
            clip.stop();
            System.out.println("🛑 Detenido: " + clave);
        }
    }
}

