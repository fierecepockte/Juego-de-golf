import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Font;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Registro extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtNombre;
    private JTextField txtCI;
    private JTextField txtFNac;
    private JComboBox<String> boxCarrera;
    private JRadioButton rbtnMasculino;
    private JRadioButton rbtnFemenino;
    private ButtonGroup bgSexo;  // Grupo declarado como campo
    private JCheckBox chboxDeporte;
    private JCheckBox chboxMusica;
    private JCheckBox chboxLectura;
    private JButton btnRegistrar;
    private JButton btnLimpiar;
    private JButton btnSalir;
    private JTable tabla;

    // Array List para guardar los datos
    private ArrayList<Estudiante> listaEstudiantes = new ArrayList<>();
    private DefaultTableModel tableModel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Registro frame = new Registro();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    
    //codigo de los elementos del formulario
    public Registro() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 650, 450);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(218, 243, 221));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Título
        JLabel lblTitulo = new JLabel("Registro de Estudiantes");
        lblTitulo.setForeground(new Color(79, 196, 94));
        lblTitulo.setFont(new Font("Franklin Gothic Demi Cond", Font.BOLD | Font.ITALIC, 18));
        lblTitulo.setBounds(220, 10, 200, 25);
        contentPane.add(lblTitulo);

        // Nombre
        JLabel lblNombre = new JLabel("Nombre Completo:");
        lblNombre.setForeground(new Color(79, 196, 94));
        lblNombre.setFont(new Font("Arial", Font.PLAIN, 12));
        lblNombre.setBounds(23, 50, 120, 20);
        contentPane.add(lblNombre);
        txtNombre = new JTextField();
        txtNombre.setBounds(150, 50, 300, 20);
        contentPane.add(txtNombre);
        txtNombre.setColumns(10);

        // Cédula
        JLabel lblCI = new JLabel("Cédula Identidad:");
        lblCI.setForeground(new Color(79, 196, 94));
        lblCI.setFont(new Font("Arial", Font.PLAIN, 12));
        lblCI.setBounds(23, 80, 120, 20);
        contentPane.add(lblCI);
        txtCI = new JTextField();
        txtCI.setBounds(150, 80, 300, 20);
        contentPane.add(txtCI);
        txtCI.setColumns(10);

        // Fecha
        JLabel lblFNac = new JLabel("Fecha de Nacimiento:");
        lblFNac.setForeground(new Color(79, 196, 94));
        lblFNac.setFont(new Font("Arial", Font.PLAIN, 12));
        lblFNac.setBounds(23, 110, 180, 20);
        contentPane.add(lblFNac);
        txtFNac = new JTextField();
        txtFNac.setBounds(200, 110, 250, 20);
        contentPane.add(txtFNac);
        txtFNac.setColumns(10);

        // Carreras
        JLabel lblCarrera = new JLabel("Carrera:");
        lblCarrera.setForeground(new Color(79, 196, 94));
        lblCarrera.setFont(new Font("Arial", Font.PLAIN, 12));
        lblCarrera.setBounds(23, 140, 80, 20);
        contentPane.add(lblCarrera);
        boxCarrera = new JComboBox<>();
        boxCarrera.setBounds(150, 140, 300, 22);
        boxCarrera.addItem("Seleccionar...");
        boxCarrera.addItem("Ingeniería en Telecomunicaciones");
        boxCarrera.addItem("Ingeniería en Sistemas");
        boxCarrera.addItem("Ingeniería Industrial");
        boxCarrera.addItem("Ingeniería Mecatrónica");
        boxCarrera.addItem("Ingeniería Bioquímica");
        boxCarrera.addItem("Ingeniería Química");
        boxCarrera.addItem("Ingeniería Civil");
        boxCarrera.addItem("Derecho");
        boxCarrera.addItem("Economía");
        boxCarrera.addItem("Administración de Empresas");
        boxCarrera.addItem("Diseño Gráfico");
        boxCarrera.addItem("Arquitectura");
        boxCarrera.addItem("Medicina");
        contentPane.add(boxCarrera);

        // Sexo
        JLabel lblSexo = new JLabel("Sexo:");
        lblSexo.setForeground(new Color(79, 196, 94));
        lblSexo.setFont(new Font("Arial", Font.PLAIN, 12));
        lblSexo.setBounds(23, 170, 50, 20);
        contentPane.add(lblSexo);
        rbtnMasculino = new JRadioButton("Masculino");
        rbtnMasculino.setBackground(new Color(218, 243, 221));
        rbtnMasculino.setBounds(150, 170, 100, 20);
        contentPane.add(rbtnMasculino);
        rbtnFemenino = new JRadioButton("Femenino");
        rbtnFemenino.setBackground(new Color(218, 243, 221));
        rbtnFemenino.setBounds(260, 170, 100, 20);
        contentPane.add(rbtnFemenino);
        // agrupamos botones para elegir solamente masculino o femenino
        bgSexo = new ButtonGroup();
        bgSexo.add(rbtnMasculino);
        bgSexo.add(rbtnFemenino);

        // Hobbies
        chboxDeporte = new JCheckBox("Deporte");
        chboxDeporte.setBackground(new Color(218, 243, 221));
        chboxDeporte.setBounds(150, 200, 80, 20);
        contentPane.add(chboxDeporte);
        chboxMusica = new JCheckBox("Música");
        chboxMusica.setBackground(new Color(218, 243, 221));
        chboxMusica.setBounds(240, 200, 80, 20);
        contentPane.add(chboxMusica);
        chboxLectura = new JCheckBox("Lectura");
        chboxLectura.setBackground(new Color(218, 243, 221));
        chboxLectura.setBounds(330, 200, 80, 20);
        contentPane.add(chboxLectura);

        // Botones
        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 12));
        btnRegistrar.setBounds(480, 50, 120, 25);
        contentPane.add(btnRegistrar);
        btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setFont(new Font("Arial", Font.BOLD, 12));
        btnLimpiar.setBounds(480, 90, 120, 25);
        contentPane.add(btnLimpiar);
        btnSalir = new JButton("Salir");
        btnSalir.setFont(new Font("Arial", Font.BOLD, 12));
        btnSalir.setBounds(480, 130, 120, 25);
        contentPane.add(btnSalir);

        // Creacion de tabla
        tableModel = new DefaultTableModel(new Object[]{"Nombre","Cédula","Fecha Nac.","Carrera","Sexo","Hobbies"}, 0);
        tabla = new JTable(tableModel);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBounds(23, 240, 577, 150);
        contentPane.add(scroll);

        // Listeners
        //accion de registrar
        btnRegistrar.addActionListener(e -> registrarEstudiante());
        //Accion de Limpiar
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        //accion de salir con respectivo mensaje 
        btnSalir.addActionListener(e -> {
            int opcion = JOptionPane.showConfirmDialog(
                this,
                "¿Estás seguro de que quieres salir?",
                "Confirmar salida",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE
            );
            if (opcion == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });
    }
    //Registro
    private void registrarEstudiante() {
        String nombre = txtNombre.getText().trim();
        String ci = txtCI.getText().trim();
        String fnac = txtFNac.getText().trim();
        String carrera = (String) boxCarrera.getSelectedItem();
        String sexo = rbtnMasculino.isSelected() ? "Masculino" : rbtnFemenino.isSelected() ? "Femenino" : "";
        ArrayList<String> hobbies = new ArrayList<>();
        if (chboxDeporte.isSelected()) hobbies.add("Deporte");
        if (chboxMusica.isSelected()) hobbies.add("Música");
        if (chboxLectura.isSelected()) hobbies.add("Lectura");

        // Validaciones
        //Validacion de que los campos esten llenos con el respectivo mensaje de error
        if (nombre.isEmpty() || ci.isEmpty() || fnac.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe completar todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
      //Validacion de que la fecha este correcta con el respectivo mensaje de error
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try { sdf.parse(fnac); }
        catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa una fecha válida con formato dd/MM/yyyy.", "Error Fecha", JOptionPane.ERROR_MESSAGE);
            return;
        }
      //Validacion de que se elija una carrera con el respectivo mensaje de error
        if (carrera.equals("Seleccionar...")) {
            JOptionPane.showMessageDialog(this, "Por favor selecciona una carrera válida.", "Error Carrera", JOptionPane.ERROR_MESSAGE);
            return;
        }
      //Validacion de que la cedula sea numerica con el respectivo mensaje de error
        if (!ci.matches("\\d+")) {
            JOptionPane.showMessageDialog(this, "La cédula debe ser numérica.", "Error Cédula", JOptionPane.ERROR_MESSAGE);
            return;
        }
      //Validacion de que se elija al menos un hobby con el respectivo mensaje de error
        if (hobbies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecciona al menos un hobby.", "Error Hobbies", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Guardar
        Estudiante est = new Estudiante(nombre, ci, fnac, carrera, sexo, String.join(", ", hobbies));
        listaEstudiantes.add(est);
        tableModel.addRow(new Object[]{nombre, ci, fnac, carrera, sexo, est.getHobbies()});
        JOptionPane.showMessageDialog(this, "Estudiante registrado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        limpiarFormulario();
    }

    //Limpiar
    private void limpiarFormulario() {
        txtNombre.setText("");
        txtCI.setText("");
        txtFNac.setText("");
        boxCarrera.setSelectedIndex(0);
        // Limpia selección de sexo
        bgSexo.clearSelection();
        chboxDeporte.setSelected(false);
        chboxMusica.setSelected(false);
        chboxLectura.setSelected(false);
    }

    //datos de cada estudiante
    private class Estudiante {
        private String nombre, ci, fnac, carrera, sexo, hobbies;
        public Estudiante(String nombre, String ci, String fnac, String carrera, String sexo, String hobbies) {
            this.nombre = nombre; this.ci = ci; this.fnac = fnac;
            this.carrera = carrera; this.sexo = sexo; this.hobbies = hobbies;
        }
        public String getHobbies() { return hobbies; }
    }
}
